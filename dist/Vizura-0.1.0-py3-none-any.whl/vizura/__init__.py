# __init__.py (in my_package/)
from .app_pypi import run_dashboard
